OpenGl 1.1 Examples
===========
  These example are only for 1.1 and will no longer be updated.<BR>

`OpenGLDemo` is a very basic framework that draws a 2d square

`OpenGL`  show a triangle, cube, and lighting

`BouncyCube`, `solarSystem`, and `Vortex`  show moving and touch event with the onpengl.
  
---

These are example code for University of Wyoming, Cosc 4730 Mobile Programming course and cosc 4735 Advance Mobile Programing course. 
All examples are for Android.
